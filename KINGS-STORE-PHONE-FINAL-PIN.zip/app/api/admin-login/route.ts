import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { adminToken, panelConfigured, secureEqual } from "@/lib/admin-auth";

const attempts = new Map<string, { count: number; resetAt: number }>();

export async function POST(request: Request) {
  if (!panelConfigured()) {
    return NextResponse.json({ error: "KING_PANEL_PIN and KING_PANEL_SECRET are not configured" }, { status: 503 });
  }

  const forwarded = request.headers.get("x-forwarded-for") || "unknown";
  const ip = forwarded.split(",")[0].trim();
  const now = Date.now();
  const current = attempts.get(ip);
  if (current && current.resetAt > now && current.count >= 8) {
    return NextResponse.json({ error: "Too many attempts. Try again later." }, { status: 429 });
  }

  const body = await request.json().catch(() => ({}));
  const configuredPin = process.env.KING_PANEL_PIN || "";
  const submittedPin = String(body.pin || "");
  if (!secureEqual(submittedPin, configuredPin)) {
    const next = current && current.resetAt > now
      ? { count: current.count + 1, resetAt: current.resetAt }
      : { count: 1, resetAt: now + 15 * 60 * 1000 };
    attempts.set(ip, next);
    return NextResponse.json({ error: "Invalid PIN" }, { status: 401 });
  }

  attempts.delete(ip);
  const cookieStore = await cookies();
  cookieStore.set("ks_admin", adminToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: 60 * 60 * 8,
  });
  return NextResponse.json({ ok: true });
}
