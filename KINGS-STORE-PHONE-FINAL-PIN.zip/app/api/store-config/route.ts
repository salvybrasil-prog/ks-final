import { NextResponse } from "next/server";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import { normalizeStoreConfig } from "@/lib/store-config";

const CONFIG_KEY = "ks:store-config:v2";

function redisCredentials() {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL || "";
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN || "";
  return { url: url.replace(/\/$/, ""), token };
}

async function command(args: unknown[]) {
  const { url, token } = redisCredentials();
  if (!url || !token) return { configured: false as const, result: null };
  const response = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(args),
    cache: "no-store",
  });
  if (!response.ok) throw new Error(`Remote config error ${response.status}`);
  const json = await response.json();
  return { configured: true as const, result: json.result };
}

export async function GET() {
  try {
    const response = await command(["GET", CONFIG_KEY]);
    if (!response.configured || !response.result) {
      return NextResponse.json({ configured: response.configured, config: null }, { headers: { "Cache-Control": "no-store" } });
    }
    const raw = typeof response.result === "string" ? JSON.parse(response.result) : response.result;
    return NextResponse.json({ configured: true, config: normalizeStoreConfig(raw) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ configured: Boolean(redisCredentials().url), config: null, error: "Could not load remote configuration" }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  if (!(await isAdminAuthenticated())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const config = normalizeStoreConfig(await request.json().catch(() => ({})));
  try {
    const response = await command(["SET", CONFIG_KEY, JSON.stringify(config)]);
    if (!response.configured) return NextResponse.json({ saved: false, configured: false, config });
    return NextResponse.json({ saved: true, configured: true, config });
  } catch {
    return NextResponse.json({ saved: false, configured: true, error: "Could not save remote configuration" }, { status: 500 });
  }
}
