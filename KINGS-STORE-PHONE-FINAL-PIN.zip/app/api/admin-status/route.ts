import { NextResponse } from "next/server";
import { isAdminAuthenticated, panelConfigured } from "@/lib/admin-auth";

export async function GET() {
  return NextResponse.json({
    authenticated: await isAdminAuthenticated(),
    configured: panelConfigured(),
  });
}
