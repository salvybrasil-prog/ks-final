import type { Metadata } from "next";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://kingsalvy.store"),
  title: "Kings Store | Digital Marketplace",
  description: "Recargas, servicios digitales, social media, streaming y más.",
  icons: {
    icon: "/ks-logo.png"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}
