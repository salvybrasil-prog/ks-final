export type Currency = "MXN" | "USD";
export type Lang = "es" | "en";

export function formatPrice(priceMXN:number,priceUSD:number,currency:Currency):string{
  const amount=currency==="MXN"?priceMXN:priceUSD;
  return new Intl.NumberFormat(currency==="MXN"?"es-MX":"en-US",{style:"currency",currency,maximumFractionDigits:currency==="MXN"?0:2}).format(amount);
}

export function telegramLink(message="", usernameOverride=""):string{
  const username=(usernameOverride||process.env.NEXT_PUBLIC_TELEGRAM_USERNAME||"").trim().replace(/^@/,"");
  if(username)return `https://t.me/${username}`;
  const site=process.env.NEXT_PUBLIC_SITE_URL||"https://kingsalvy.store";
  return `https://t.me/share/url?url=${encodeURIComponent(site)}&text=${encodeURIComponent(message)}`;
}

export function discordLink(override=""):string{
  return (override||process.env.NEXT_PUBLIC_DISCORD_INVITE||"#").trim()||"#";
}
