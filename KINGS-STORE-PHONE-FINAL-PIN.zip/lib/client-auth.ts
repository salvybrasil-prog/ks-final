export type AuthProvider = "google" | "apple" | "azure";

export type ClientAccount = {
  id: string;
  email: string;
  name: string;
  avatarUrl: string;
  provider: string;
};

type StoredSession = {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
};

const SESSION_KEY = "ks_client_auth_session";

export function authConfigured() {
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

function baseUrl() {
  return (process.env.NEXT_PUBLIC_SUPABASE_URL || "").replace(/\/$/, "");
}

function anonKey() {
  return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
}

function saveSession(session: StoredSession | null) {
  if (typeof window === "undefined") return;
  if (!session) localStorage.removeItem(SESSION_KEY);
  else localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

function loadSession(): StoredSession | null {
  if (typeof window === "undefined") return null;
  try {
    const value = JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    return value?.accessToken ? value : null;
  } catch {
    return null;
  }
}

function accountFromUser(user: any): ClientAccount {
  const metadata = user?.user_metadata || {};
  const identityProvider = user?.app_metadata?.provider || user?.identities?.[0]?.provider || "email";
  return {
    id: String(user?.id || ""),
    email: String(user?.email || ""),
    name: String(metadata.full_name || metadata.name || metadata.user_name || user?.email || "King Store Client"),
    avatarUrl: String(metadata.avatar_url || metadata.picture || ""),
    provider: String(identityProvider),
  };
}

async function refreshSession(session: StoredSession): Promise<StoredSession | null> {
  if (!session.refreshToken || !authConfigured()) return null;
  const response = await fetch(`${baseUrl()}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: { apikey: anonKey(), Authorization: `Bearer ${anonKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: session.refreshToken }),
  });
  if (!response.ok) return null;
  const data = await response.json();
  const next = {
    accessToken: String(data.access_token || ""),
    refreshToken: String(data.refresh_token || session.refreshToken),
    expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000,
  };
  saveSession(next);
  return next;
}

export function consumeAuthCallback(): boolean {
  if (typeof window === "undefined" || !authConfigured()) return false;
  const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  const accessToken = hash.get("access_token");
  if (!accessToken) return false;
  const session: StoredSession = {
    accessToken,
    refreshToken: hash.get("refresh_token") || "",
    expiresAt: Date.now() + Number(hash.get("expires_in") || 3600) * 1000,
  };
  saveSession(session);
  window.history.replaceState({}, "", window.location.pathname + window.location.search);
  return true;
}

export async function getClientAccount(): Promise<ClientAccount | null> {
  if (!authConfigured()) return null;
  let session = loadSession();
  if (!session) return null;
  if (session.expiresAt < Date.now() + 30_000) session = await refreshSession(session);
  if (!session) {
    saveSession(null);
    return null;
  }
  const response = await fetch(`${baseUrl()}/auth/v1/user`, {
    headers: { apikey: anonKey(), Authorization: `Bearer ${session.accessToken}` },
  });
  if (!response.ok) {
    saveSession(null);
    return null;
  }
  return accountFromUser(await response.json());
}

export function startOAuth(provider: AuthProvider) {
  if (!authConfigured() || typeof window === "undefined") return false;
  const redirectTo = `${window.location.origin}${window.location.pathname}`;
  const params = new URLSearchParams({
    provider,
    redirect_to: redirectTo,
    flow_type: "implicit",
    apikey: anonKey(),
  });
  window.location.href = `${baseUrl()}/auth/v1/authorize?${params.toString()}`;
  return true;
}

export async function sendMagicLink(email: string) {
  if (!authConfigured()) throw new Error("Client authentication is not configured.");
  const redirectTo = typeof window === "undefined" ? "" : `${window.location.origin}${window.location.pathname}`;
  const response = await fetch(`${baseUrl()}/auth/v1/otp?redirect_to=${encodeURIComponent(redirectTo)}`, {
    method: "POST",
    headers: { apikey: anonKey(), Authorization: `Bearer ${anonKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify({ email, create_user: true }),
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.msg || body.message || "Could not send the login link.");
  }
}

export async function signOutClient() {
  const session = loadSession();
  if (session && authConfigured()) {
    await fetch(`${baseUrl()}/auth/v1/logout`, {
      method: "POST",
      headers: { apikey: anonKey(), Authorization: `Bearer ${session.accessToken}` },
    }).catch(() => {});
  }
  saveSession(null);
}
