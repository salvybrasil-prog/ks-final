import { createHash, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

export function panelConfigured() {
  return Boolean(process.env.KING_PANEL_PIN && process.env.KING_PANEL_SECRET);
}

export function adminToken() {
  const pin = process.env.KING_PANEL_PIN || "";
  const secret = process.env.KING_PANEL_SECRET || "";
  return createHash("sha256").update(`${pin}:${secret}:king-store-panel-v2`).digest("hex");
}

export function secureEqual(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

export async function isAdminAuthenticated() {
  if (!panelConfigured()) return false;
  const cookieStore = await cookies();
  return secureEqual(cookieStore.get("ks_admin")?.value || "", adminToken());
}
