import { products as seedProducts, type Product, type StoreCategory } from "@/data/products";

export type TitleTransform = "none" | "uppercase" | "capitalize";

export type SiteSettings = {
  titleFont: string;
  bodyFont: string;
  bodyFontSize: number;
  titleSize: number;
  cardTitleSize: number;
  priceSize: number;
  buttonSize: number;
  titleColor: string;
  accentColor: string;
  accentColor2: string;
  textColor: string;
  mutedColor: string;
  panelColor: string;
  borderColor: string;
  sectionSpacing: number;
  itemSpacing: number;
  cardPadding: number;
  cardRadius: number;
  letterSpacing: number;
  lineHeight: number;
  glowStrength: number;
  lightingIntensity: number;
  lightingSpeed: number;
  titleTransform: TitleTransform;
  flagsDesktop: boolean;
  lightingEnabled: boolean;
  animationsEnabled: boolean;
};

export type CategoryCopy = {
  es: string;
  en: string;
  descEs: string;
  descEn: string;
};

export type SiteContent = {
  storeName: string;
  heroTaglineEs: string;
  heroTaglineEn: string;
  introButtonEs: string;
  introButtonEn: string;
  featuredTitleEs: string;
  featuredTitleEn: string;
  workButtonEs: string;
  workButtonEn: string;
  footerText: string;
  announcementEs: string;
  announcementEn: string;
  telegramUsername: string;
  discordInvite: string;
  categories: Record<StoreCategory, CategoryCopy>;
};

export type StoreConfig = {
  version: 2;
  settings: SiteSettings;
  content: SiteContent;
  products: Product[];
};

export const fontOptions = [
  { label: "Lobster", value: '"Lobster","Brush Script MT",cursive' },
  { label: "Playfair Display", value: '"Playfair Display",Georgia,serif' },
  { label: "Cinzel", value: '"Cinzel",Georgia,serif' },
  { label: "Bebas Neue", value: '"Bebas Neue",Impact,sans-serif' },
  { label: "Montserrat", value: '"Montserrat",Arial,sans-serif' },
  { label: "Outfit", value: '"Outfit","Montserrat",Arial,sans-serif' },
  { label: "Arial", value: 'Arial,sans-serif' },
];

export const defaultSettings: SiteSettings = {
  titleFont: '"Lobster","Brush Script MT",cursive',
  bodyFont: '"Montserrat",Arial,sans-serif',
  bodyFontSize: 16,
  titleSize: 68,
  cardTitleSize: 34,
  priceSize: 18,
  buttonSize: 14,
  titleColor: "#f7fbff",
  accentColor: "#42a9ff",
  accentColor2: "#0f6fca",
  textColor: "#f2f7fb",
  mutedColor: "#91a4b6",
  panelColor: "#040914",
  borderColor: "#25577f",
  sectionSpacing: 72,
  itemSpacing: 22,
  cardPadding: 22,
  cardRadius: 24,
  letterSpacing: 0.02,
  lineHeight: 1.5,
  glowStrength: 0.34,
  lightingIntensity: 0.55,
  lightingSpeed: 9,
  titleTransform: "capitalize",
  flagsDesktop: true,
  lightingEnabled: true,
  animationsEnabled: true,
};

export const defaultContent: SiteContent = {
  storeName: "King Store",
  heroTaglineEs: "Servicios digitales con presencia de rey.",
  heroTaglineEn: "Digital services with a king's presence.",
  introButtonEs: "Entrar A King Store",
  introButtonEn: "Enter King Store",
  featuredTitleEs: "Categorías destacadas",
  featuredTitleEn: "Featured categories",
  workButtonEs: "¿Quieres Trabajar Con Nosotros?",
  workButtonEn: "Want To Work With Us?",
  footerText: "King Store · El Legado Continúa",
  announcementEs: "Compra segura · atención directa · entrega digital",
  announcementEn: "Secure purchase · direct support · digital delivery",
  telegramUsername: "",
  discordInvite: "",
  categories: {
    "Free Fire": { es: "Diamantes", en: "Diamonds", descEs: "Promo y diamantes ilimitados", descEn: "Promo and unlimited diamonds" },
    "Superpowers": { es: "Superpoderes", en: "Superpowers", descEs: "Herramientas iOS y Android", descEn: "iOS and Android tools" },
    "Social Media": { es: "Redes Sociales", en: "Social Media", descEs: "Seguidores, likes y vistas", descEn: "Followers, likes and views" },
    "Streaming": { es: "Streaming", en: "Streaming", descEs: "Próximamente", descEn: "Coming soon" },
    "Graphic Design": { es: "Diseño Gráfico", en: "Graphic Design", descEs: "Diseño, páginas y bots", descEn: "Design, websites and bots" },
    "Métodos": { es: "Métodos", en: "Methods", descEs: "Guías y paquetes digitales", descEn: "Digital guides and packages" },
  },
};

export const defaultStoreConfig: StoreConfig = {
  version: 2,
  settings: defaultSettings,
  content: defaultContent,
  products: seedProducts,
};

function numberIn(value: unknown, fallback: number, min: number, max: number) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
}

function text(value: unknown, fallback: string, max = 500) {
  return typeof value === "string" ? value.slice(0, max) : fallback;
}

function color(value: unknown, fallback: string) {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value : fallback;
}

function normalizeProduct(raw: Partial<Product>, index: number): Product | null {
  const category = raw.category;
  const allowed: StoreCategory[] = ["Free Fire", "Superpowers", "Social Media", "Streaming", "Graphic Design", "Métodos"];
  if (!category || !allowed.includes(category)) return null;
  const name = text(raw.name, "Producto", 100).trim() || "Producto";
  const group = text(raw.group, category, 120).trim() || category;
  const id = text(raw.id, `custom-${Date.now()}-${index}`, 120).replace(/[^a-zA-Z0-9_-]/g, "-");
  return {
    id,
    name,
    description: text(raw.description, "", 600),
    category,
    group,
    priceMXN: numberIn(raw.priceMXN, 0, 0, 1_000_000),
    priceUSD: numberIn(raw.priceUSD, 0, 0, 100_000),
    duration: raw.duration ? text(raw.duration, "", 80) : undefined,
    delivery: text(raw.delivery, "Entrega digital", 120),
    badge: raw.badge ? text(raw.badge, "", 50) : undefined,
    featured: Boolean(raw.featured),
    lifetime: Boolean(raw.lifetime),
    hidden: Boolean(raw.hidden),
    icon: raw.icon ? text(raw.icon, "", 30) : undefined,
  };
}

export function normalizeStoreConfig(raw: unknown): StoreConfig {
  const value = raw && typeof raw === "object" ? raw as Partial<StoreConfig> : {};
  const s = value.settings && typeof value.settings === "object" ? value.settings as Partial<SiteSettings> : {};
  const c = value.content && typeof value.content === "object" ? value.content as Partial<SiteContent> : {};
  const settings: SiteSettings = {
    titleFont: text(s.titleFont, defaultSettings.titleFont, 120),
    bodyFont: text(s.bodyFont, defaultSettings.bodyFont, 120),
    bodyFontSize: numberIn(s.bodyFontSize, defaultSettings.bodyFontSize, 12, 24),
    titleSize: numberIn(s.titleSize, defaultSettings.titleSize, 30, 110),
    cardTitleSize: numberIn(s.cardTitleSize, defaultSettings.cardTitleSize, 20, 64),
    priceSize: numberIn(s.priceSize, defaultSettings.priceSize, 13, 32),
    buttonSize: numberIn(s.buttonSize, defaultSettings.buttonSize, 11, 24),
    titleColor: color(s.titleColor, defaultSettings.titleColor),
    accentColor: color(s.accentColor, defaultSettings.accentColor),
    accentColor2: color(s.accentColor2, defaultSettings.accentColor2),
    textColor: color(s.textColor, defaultSettings.textColor),
    mutedColor: color(s.mutedColor, defaultSettings.mutedColor),
    panelColor: color(s.panelColor, defaultSettings.panelColor),
    borderColor: color(s.borderColor, defaultSettings.borderColor),
    sectionSpacing: numberIn(s.sectionSpacing, defaultSettings.sectionSpacing, 24, 150),
    itemSpacing: numberIn(s.itemSpacing, defaultSettings.itemSpacing, 6, 70),
    cardPadding: numberIn(s.cardPadding, defaultSettings.cardPadding, 10, 60),
    cardRadius: numberIn(s.cardRadius, defaultSettings.cardRadius, 0, 48),
    letterSpacing: numberIn(s.letterSpacing, defaultSettings.letterSpacing, 0, 0.25),
    lineHeight: numberIn(s.lineHeight, defaultSettings.lineHeight, 1.1, 2.2),
    glowStrength: numberIn(s.glowStrength, defaultSettings.glowStrength, 0, 1),
    lightingIntensity: numberIn(s.lightingIntensity, defaultSettings.lightingIntensity, 0, 1),
    lightingSpeed: numberIn(s.lightingSpeed, defaultSettings.lightingSpeed, 4, 30),
    titleTransform: ["none", "uppercase", "capitalize"].includes(String(s.titleTransform)) ? s.titleTransform as TitleTransform : defaultSettings.titleTransform,
    flagsDesktop: s.flagsDesktop === undefined ? defaultSettings.flagsDesktop : Boolean(s.flagsDesktop),
    lightingEnabled: s.lightingEnabled === undefined ? defaultSettings.lightingEnabled : Boolean(s.lightingEnabled),
    animationsEnabled: s.animationsEnabled === undefined ? defaultSettings.animationsEnabled : Boolean(s.animationsEnabled),
  };

  const categories = { ...defaultContent.categories };
  if (c.categories && typeof c.categories === "object") {
    (Object.keys(categories) as StoreCategory[]).forEach((key) => {
      const incoming = c.categories?.[key];
      if (!incoming) return;
      categories[key] = {
        es: text(incoming.es, categories[key].es, 80),
        en: text(incoming.en, categories[key].en, 80),
        descEs: text(incoming.descEs, categories[key].descEs, 180),
        descEn: text(incoming.descEn, categories[key].descEn, 180),
      };
    });
  }

  const content: SiteContent = {
    storeName: text(c.storeName, defaultContent.storeName, 80),
    heroTaglineEs: text(c.heroTaglineEs, defaultContent.heroTaglineEs),
    heroTaglineEn: text(c.heroTaglineEn, defaultContent.heroTaglineEn),
    introButtonEs: text(c.introButtonEs, defaultContent.introButtonEs, 80),
    introButtonEn: text(c.introButtonEn, defaultContent.introButtonEn, 80),
    featuredTitleEs: text(c.featuredTitleEs, defaultContent.featuredTitleEs, 120),
    featuredTitleEn: text(c.featuredTitleEn, defaultContent.featuredTitleEn, 120),
    workButtonEs: text(c.workButtonEs, defaultContent.workButtonEs, 120),
    workButtonEn: text(c.workButtonEn, defaultContent.workButtonEn, 120),
    footerText: text(c.footerText, defaultContent.footerText, 160),
    announcementEs: text(c.announcementEs, defaultContent.announcementEs, 200),
    announcementEn: text(c.announcementEn, defaultContent.announcementEn, 200),
    telegramUsername: text(c.telegramUsername, defaultContent.telegramUsername, 80).replace(/^@/, ""),
    discordInvite: text(c.discordInvite, defaultContent.discordInvite, 250),
    categories,
  };

  const normalizedProducts = Array.isArray(value.products)
    ? value.products.map((item, index) => normalizeProduct(item, index)).filter(Boolean) as Product[]
    : seedProducts;

  return {
    version: 2,
    settings,
    content,
    products: normalizedProducts.length ? normalizedProducts : seedProducts,
  };
}
