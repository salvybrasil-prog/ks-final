# King Store — Full Control Build

This package contains the complete storefront, the restored private **Panel** button, continuous page lighting, centered cart controls under every product, desktop country flags, upgraded vector emblems, and customer sign-in options.


## Phone-First Storefront Update

- The floating cart and header cart controls are smaller on phones.
- Every category price graph starts closed; customers must tap **View Options / Ver Opciones** to reveal products.
- Promo Diamonds and Unlimited Diamonds also start closed.
- Every product keeps its own centered minus / quantity / plus control directly under both prices.
- Storefront headings and buttons use title case instead of all capitals.
- Mexico and United States flags are permanently visible beside every price on desktop and mobile.

## Deploy on Vercel

1. Upload the project to GitHub.
2. Import the repository into Vercel as a Next.js project.
3. Keep the build command as `npm run build`.
4. Add the environment variables from `.env.example`.
5. Redeploy after adding or changing environment variables.


## Set Your King Panel PIN On Vercel

1. Open your project in **Vercel**.
2. Go to **Settings → Environment Variables**.
3. Add `KING_PANEL_PIN` and enter the private numeric PIN you want, for example `4826`.
4. Add `KING_PANEL_SECRET` and enter a long random private value of at least 32 characters.
5. Apply both variables to **Production**, **Preview**, and **Development**.
6. Save the variables, open **Deployments**, and redeploy the newest deployment.
7. Open the website, press the **Panel** button, and enter the PIN from `KING_PANEL_PIN`.

Do not name either variable with `NEXT_PUBLIC`. The PIN is checked only on the server, and the unlocked session lasts eight hours.

## Private King Panel

The **Panel** button is visible in the desktop navigation and side menu, but the panel itself cannot open without the private server PIN.

Required server-only variables:

- `KING_PANEL_PIN`
- `KING_PANEL_SECRET`

The PIN is checked by a server route. The successful session is stored in a secure HttpOnly cookie for eight hours. Failed attempts are rate-limited. Never prefix either private value with `NEXT_PUBLIC`.

### What the panel can edit

- Every product name, category, group/table, description, duration, emblem, MXN price, USD price, order, visibility, and featured status.
- Add, duplicate, move, hide, or delete products.
- Title font and body font separately.
- General font size, title size, card-title size, price size, and button size.
- Title formatting, line height, letter spacing, card padding, page spacing, item spacing, and corner radius.
- Title, accent, text, muted-text, panel, and border colors.
- Continuous lighting, animation, lighting speed, lighting intensity, and card glow.
- Desktop flags.
- Home-page text, entry button, announcements, footer, category names/descriptions, Telegram username, Discord link, and work-with-us text.
- Complete JSON export/import backup.

### Publishing panel changes for all customers

Connect Vercel KV or an Upstash Redis database and add one of these variable pairs:

- `KV_REST_API_URL` and `KV_REST_API_TOKEN`, or
- `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`.

With Redis configured, **Publish Changes** updates the storefront for every visitor. Without Redis, edits still save in that browser and can be moved using Export/Import.

## Customer accounts

The account page supports:

- Google
- Apple
- Microsoft
- Secure email magic links

Add:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

In the Supabase dashboard, enable the providers you want under Authentication, add their provider credentials, and add your production domain to the allowed redirect URLs. Email magic links work through the same Supabase project.

The website remains usable without Supabase, but the provider buttons stay disabled until these two public variables are configured.

## Storefront changes included

- The Panel button is restored and always available behind the private PIN gate.
- Mexico and United States flags are explicitly displayed in desktop and mobile price cells.
- Every sellable item has its own centered minus / quantity / plus control beneath its two prices.
- Category and social-media placeholders were replaced with clean vector emblems.
- Animated blue ambient lighting and subtle lightning remain active throughout the full page.
- Titles and normal text use independent fonts and colors controlled from King Panel.
- Google, Apple, Microsoft, and email account access is prepared as a real Supabase Auth integration.
- The existing logo file is preserved without modification.
