export type StoreCategory =
  | "Free Fire"
  | "Superpowers"
  | "Social Media"
  | "Streaming"
  | "Graphic Design"
  | "Métodos";

export type Product = {
  id: string;
  name: string;
  description: string;
  category: StoreCategory;
  group: string;
  priceMXN: number;
  priceUSD: number;
  duration?: string;
  delivery: string;
  badge?: string;
  featured?: boolean;
  lifetime?: boolean;
  hidden?: boolean;
  icon?: string;
};

const p = (product: Product) => product;
const simple = (
  id: string,
  name: string,
  category: StoreCategory,
  group: string,
  priceMXN: number,
  priceUSD: number,
  duration?: string
) => p({ id, name, category, group, priceMXN, priceUSD, duration, description:"", delivery:"Entrega digital" });

export const products: Product[] = [
  // PROMO DIAMONDS — total amount shown on each card
  ...[
    ["341",35,2],["572",70,3.5],["1166",120,6],["2398",220,11],["6160",600,30]
  ].map(([amount,mxn,usd])=>simple(`promo-${amount}`,`${amount} Diamantes`,"Free Fire","Promo Diamonds",Number(mxn),Number(usd))),

  // DIAMANTES X SIEMPRE / UNLIMITED
  ...[
    ["341",50,2.5],["572",80,4],["913",120,6],["1166",160,8],["1505",200,10],
    ["2079",270,23.5],["2398",300,15],["3564",440,22],["4796",550,35],["6200",700,35]
  ].map(([amount,mxn,usd])=>simple(`unlimited-${amount}`,`${amount} Diamantes`,"Free Fire","Unlimited Diamonds",Number(mxn),Number(usd))),

  // iOS SUPERPOWERS
  ...[
    ["MIGUL",[["1 Día",160,8],["1 Semana",260,13],["1 Mes",500,25]]],
    ["Potatso",[["1 Día",60,3],["1 Semana",200,10],["1 Mes",300,15]]],
    ["FLO-BAN",[["1 Día",120,6],["1 Semana",360,18],["1 Mes",630,25]]]
  ].flatMap(([name,plans])=>(plans as [string,number,number][]).map(([duration,mxn,usd])=>simple(`ios-${String(name).toLowerCase()}-${duration.replaceAll(" ","-").toLowerCase()}`,String(name),"Superpowers","iOS",mxn,usd,duration))),

  // ANDROID SUPERPOWERS
  ...[
    ["DRIP",[["3 Días",60,3],["1 Semana",120,6],["1 Mes",200,10]]],
    ["Cuban",[["1 Día",40,2],["1 Semana",100,5],["1 Mes",160,8]]],
    ["HG",[["1 Día",60,3],["1 Semana",100,5],["1 Mes",160,8]]]
  ].flatMap(([name,plans])=>(plans as [string,number,number][]).map(([duration,mxn,usd])=>simple(`android-${String(name).toLowerCase()}-${duration.replaceAll(" ","-").toLowerCase()}`,String(name),"Superpowers","Android",mxn,usd,duration))),

  // INSTAGRAM FOLLOWERS — NO REFILL / REFILL
  ...[
    ["1K",40,2],["2K",80,4],["3K",120,6],["4K",160,8],["5K",200,10],["10K",350,17.5],["50K",900,45],["100K",1200,60]
  ].map(([q,mxn,usd])=>simple(`ig-followers-nr-${q}`,String(q),"Social Media","Instagram Followers · No Refill",Number(mxn),Number(usd))),
  ...[
    ["1K",60,3],["2K",120,6],["3K",180,9],["4K",240,12],["5K",300,15],["10K",500,25],["50K",1500,75],["100K",2400,120]
  ].map(([q,mxn,usd])=>simple(`ig-followers-r-${q}`,String(q),"Social Media","Instagram Followers · Refill",Number(mxn),Number(usd))),

  // INSTAGRAM LIKES — NO REFILL / REFILL
  ...[
    ["1K",30,1.5],["2K",60,3],["3K",90,4.5],["4K",120,6],["5K",150,7.5],["10K",250,12.5],["50K",600,30],["100K",1000,50]
  ].map(([q,mxn,usd])=>simple(`ig-likes-nr-${q}`,String(q),"Social Media","Instagram Likes · No Refill",Number(mxn),Number(usd))),
  ...[
    ["1K",50,2.5],["2K",100,5],["3K",150,7.5],["4K",200,10],["5K",250,12.5],["10K",450,22.5],["50K",1000,50],["100K",1500,75]
  ].map(([q,mxn,usd])=>simple(`ig-likes-r-${q}`,String(q),"Social Media","Instagram Likes · Refill",Number(mxn),Number(usd))),

  // INSTAGRAM VIEWS
  ...[
    ["1K",30,1.5],["2K",60,3],["3K",90,4.5],["4K",120,6],["5K",150,7.5],["10K",250,12.5],["50K",500,25],["100K",750,37.5],["500K",3750,187.5]
  ].map(([q,mxn,usd])=>simple(`ig-views-${q}`,String(q),"Social Media","Instagram Views",Number(mxn),Number(usd))),

  // FACEBOOK FOLLOWERS
  ...[
    ["1K",30,1.5],["2K",60,3],["3K",90,4.5],["4K",120,6],["5K",150,7.5],["10K",260,13],["50K",1000,50],["100K",2000,100]
  ].map(([q,mxn,usd])=>simple(`fb-nr-${q}`,String(q),"Social Media","Facebook Followers · No Refill",Number(mxn),Number(usd))),
  ...[
    ["1K",60,3],["2K",120,6],["3K",180,9],["4K",240,12],["5K",300,15],["10K",550,27.5],["50K",1750,87.5],["100K",3500,175]
  ].map(([q,mxn,usd])=>simple(`fb-r-${q}`,String(q),"Social Media","Facebook Followers · Refill",Number(mxn),Number(usd))),

  // TIKTOK FOLLOWERS
  ...[
    ["1K",50,2.5],["2K",100,5],["3K",150,7.5],["4K",200,10],["5K",250,12.5],["10K",500,25],["15K",750,37.5],["50K",2200,110]
  ].map(([q,mxn,usd])=>simple(`tt-nr-${q}`,String(q),"Social Media","TikTok Followers · No Refill",Number(mxn),Number(usd))),
  ...[
    ["1K",75,3.75],["2K",150,7.5],["3K",225,11.25],["4K",300,15],["5K",375,18.75],["10K",750,37.5],["15K",975,48.75],["50K",3000,150]
  ].map(([q,mxn,usd])=>simple(`tt-r-${q}`,String(q),"Social Media","TikTok Followers · Refill",Number(mxn),Number(usd))),

  // TELEGRAM MEMBERS — image only provides MXN; USD uses 20 MXN = 1 USD for consistent cart totals.
  ...[
    ["1K",50],["2K",100],["3K",150],["4K",200],["5K",250],["10K",400],["50K",1600]
  ].map(([q,mxn])=>simple(`tg-${q}`,String(q),"Social Media","Telegram Members",Number(mxn),Number(mxn)/20)),

  // EXISTING SERVICES
  ...[
    ["Logo Design",80,4],["Banner",120,6],["Instagram Posts & Stories",140,7],["Flyers",180,9],
    ["Business Cards",200,10],["Menus & Price Sheets",240,12],["Stream Overlays",300,15],
    ["CUSTOM AI BOTS",300,15],["FULL CUSTOM WEBSITE",2000,100]
  ].map(([name,mxn,usd],i)=>{
    const item=simple(`design-${i}`,String(name),"Graphic Design","Graphic Design Services",Number(mxn),Number(usd));
    if(name==="CUSTOM AI BOTS") return {...item,duration:"Lifetime",lifetime:true};
    return item;
  }),

  simple("method-ff-promo","Promo Método","Métodos","Free Fire Métodos",300,15),
  simple("method-ff-unlimited","Unlimited Método","Métodos","Free Fire Métodos",500,25),
  simple("method-ff-combo","Combo Método","Métodos","Free Fire Métodos",650,32.5),
  simple("method-superpowers","Superpower Método","Métodos","Superpower Método",600,30),
  simple("method-social","Social Media Método","Métodos","Social Media Método",400,20),
  simple("method-450","450+ Métodos","Métodos","450+ Métodos",2000,100)
];

export const categories: StoreCategory[] = ["Free Fire","Superpowers","Social Media","Streaming","Graphic Design","Métodos"];
