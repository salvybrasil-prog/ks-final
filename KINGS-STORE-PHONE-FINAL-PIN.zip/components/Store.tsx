"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from "react";
import {
  Apple, ArrowLeft, Bell, ChevronDown, ChevronRight, ChevronUp, Chrome, CircleDollarSign,
  CreditCard, Crown, Gem, Globe2, Home, LayoutGrid, LockKeyhole, LogIn, LogOut,
  MessagesSquare, Minus, Package, Plus, ReceiptText, Search, Send, ShieldCheck, ShoppingBag,
  Trash2, Upload, User, Users, Volume2, VolumeX, WalletCards, X
} from "lucide-react";
import { categories, type Product, type StoreCategory } from "@/data/products";
import { discordLink, telegramLink, type Lang } from "@/lib/format";
import {
  defaultStoreConfig, fontOptions, normalizeStoreConfig, type CategoryCopy, type SiteContent,
  type SiteSettings, type StoreConfig
} from "@/lib/store-config";
import {
  authConfigured, consumeAuthCallback, getClientAccount, sendMagicLink, signOutClient,
  startOAuth, type AuthProvider, type ClientAccount
} from "@/lib/client-auth";

type CartLine = Product & { quantity:number };
type SocialPlatform = "Instagram"|"Facebook"|"TikTok"|"Telegram";
type InstagramType = "Followers"|"Likes"|"Views";
type AppView = "home"|"categories"|"financial"|"account"|"admin"|"category";
type OrderStatus = "Waiting"|"Payment pending"|"In progress"|"Completed"|"Canceled";
type LocalOrder = { id:string; createdAt:string; totalMXN:number; totalUSD:number; status:OrderStatus; items:number };
type AdminTab = "design"|"content"|"products"|"backup";

const socialPlatforms: {name:SocialPlatform; subtitle:string}[] = [
  {name:"Instagram",subtitle:"Followers · Likes · Views"},
  {name:"Facebook",subtitle:"Followers"},
  {name:"TikTok",subtitle:"Followers"},
  {name:"Telegram",subtitle:"Members"}
];

function money(n:number){return Number.isInteger(n)?String(n):n.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')}
function titleCase(value:string){
  return value.toLocaleLowerCase().replace(/(^|[\s/·—–-])(\p{L})/gu,(_,space,letter)=>`${space}${letter.toLocaleUpperCase()}`)
    .replace(/\bIos\b/g,"iOS").replace(/\bMxn\b/g,"MXN").replace(/\bUsd\b/g,"USD")
    .replace(/\bId\b/g,"ID").replace(/\bKs\b/g,"KS").replace(/\bAi\b/g,"AI")
    .replace(/\bHbo\b/g,"HBO").replace(/\bOxxo\b/g,"OXXO");
}
function cloneDefault(){return normalizeStoreConfig(JSON.parse(JSON.stringify(defaultStoreConfig)))}

function CategoryEmblem({category}:{category:StoreCategory}){
  if(category==="Free Fire") return <Gem/>;
  if(category==="Superpowers") return <Crown/>;
  if(category==="Social Media") return <Users/>;
  if(category==="Streaming") return <Globe2/>;
  if(category==="Graphic Design") return <LayoutGrid/>;
  return <ReceiptText/>;
}

function BrandEmblem({brand}:{brand:SocialPlatform}){
  if(brand==="Instagram") return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.4" cy="6.7" r="1" className="brand-fill"/></svg>;
  if(brand==="Facebook") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.2 21v-8h2.7l.4-3.1h-3.1V8c0-.9.3-1.6 1.6-1.6h1.7V3.6c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.1H8V13h2.8v8z" className="brand-fill"/></svg>;
  if(brand==="TikTok") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 3c.5 2.6 2 4.2 4.5 4.5v3.2c-1.7 0-3.2-.5-4.5-1.4v6.1A5.6 5.6 0 1 1 10.2 10v3.3a2.4 2.4 0 1 0 1.6 2.3V3z" className="brand-fill"/></svg>;
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m21 4-3.1 15.2c-.2 1.1-.9 1.4-1.8.9l-4.7-3.5-2.3 2.2c-.2.2-.5.5-1 .5l.4-4.8 8.7-7.9c.4-.3-.1-.5-.6-.2L5.8 13.2 1.2 11.7c-1-.3-1-1 .2-1.5L19.4 3c.8-.3 1.8.2 1.6 1z" className="brand-fill"/></svg>;
}

export default function Store(){
  const [entered,setEntered]=useState(false);
  const [menuOpen,setMenuOpen]=useState(false);
  const [cartOpen,setCartOpen]=useState(false);
  const [checkoutOpen,setCheckoutOpen]=useState(false);
  const [soundOn,setSoundOn]=useState(false);
  const [lang,setLang]=useState<Lang>("es");
  const [appView,setAppView]=useState<AppView>("home");
  const [category,setCategory]=useState<StoreCategory>("Free Fire");
  const [cart,setCart]=useState<CartLine[]>([]);
  const [config,setConfig]=useState<StoreConfig>(()=>cloneDefault());
  const [socialPlatform,setSocialPlatform]=useState<SocialPlatform|null>(null);
  const [instagramType,setInstagramType]=useState<InstagramType|null>(null);
  const [customerName,setCustomerName]=useState("");
  const [customerEmail,setCustomerEmail]=useState("");
  const [customerId,setCustomerId]=useState("");
  const [serviceId,setServiceId]=useState("");
  const [paymentMethod,setPaymentMethod]=useState("Transferencia");
  const [receiptName,setReceiptName]=useState("");
  const [formError,setFormError]=useState("");
  const [orders,setOrders]=useState<LocalOrder[]>([]);
  const [adminSearch,setAdminSearch]=useState("");
  const [adminUnlocked,setAdminUnlocked]=useState(false);
  const [adminGateOpen,setAdminGateOpen]=useState(false);
  const [adminPin,setAdminPin]=useState("");
  const [adminError,setAdminError]=useState("");
  const [publishStatus,setPublishStatus]=useState("");
  const [orderCopied,setOrderCopied]=useState(false);
  const [clientAccount,setClientAccount]=useState<ClientAccount|null>(null);
  const [authBusy,setAuthBusy]=useState(false);
  const [authMessage,setAuthMessage]=useState("");
  const audioRef=useRef<HTMLAudioElement|null>(null);
  const isEs=lang==="es";

  useEffect(()=>{
    const id=localStorage.getItem("ks_customer_id") || `KS-${Math.random().toString(36).slice(2,6).toUpperCase()}-${Date.now().toString().slice(-4)}`;
    localStorage.setItem("ks_customer_id",id); setCustomerId(id);
    setCustomerName(localStorage.getItem("ks_name")||"");
    setCustomerEmail(localStorage.getItem("ks_email")||"");
    try{setOrders(JSON.parse(localStorage.getItem("ks_orders")||"[]"))}catch{}
    try{
      const local=JSON.parse(localStorage.getItem("ks_store_config_v2")||"null");
      if(local)setConfig(normalizeStoreConfig(local));
    }catch{}
    fetch("/api/store-config",{cache:"no-store"}).then(r=>r.json()).then(v=>{
      if(v.config){const next=normalizeStoreConfig(v.config);setConfig(next);localStorage.setItem("ks_store_config_v2",JSON.stringify(next));}
    }).catch(()=>{});
    fetch("/api/admin-status",{cache:"no-store"}).then(r=>r.json()).then(v=>setAdminUnlocked(Boolean(v.authenticated))).catch(()=>{});
    const params=new URLSearchParams(window.location.search);
    if(params.get("kingpanel")==="1")setAdminGateOpen(true);

    consumeAuthCallback();
    getClientAccount().then(account=>{
      if(account){setClientAccount(account);setCustomerEmail(account.email);setCustomerName(current=>current||account.name);}
    }).catch(()=>{});
  },[]);

  const {settings,content}=config;
  const products=config.products;
  const count=cart.reduce((s,i)=>s+i.quantity,0);
  const totalMXN=cart.reduce((s,i)=>s+i.priceMXN*i.quantity,0);
  const totalUSD=cart.reduce((s,i)=>s+i.priceUSD*i.quantity,0);
  const quantities=useMemo(()=>Object.fromEntries(cart.map(x=>[x.id,x.quantity])),[cart]);
  const categoryProducts=useMemo(()=>products.filter(p=>p.category===category&&!p.hidden),[products,category]);
  const filteredAdmin=useMemo(()=>products.filter(p=>(`${p.name} ${p.group} ${p.category}`).toLowerCase().includes(adminSearch.toLowerCase())),[products,adminSearch]);

  const shellStyle={
    "--ks-title-font":settings.titleFont,"--ks-body-font":settings.bodyFont,
    "--ks-body-size":`${settings.bodyFontSize}px`,"--ks-title-size":`${settings.titleSize}px`,
    "--ks-card-title-size":`${settings.cardTitleSize}px`,"--ks-price-size":`${settings.priceSize}px`,
    "--ks-button-size":`${settings.buttonSize}px`,"--ks-title-color":settings.titleColor,
    "--ks-accent":settings.accentColor,"--ks-accent-2":settings.accentColor2,
    "--ks-text":settings.textColor,"--ks-muted":settings.mutedColor,"--ks-panel":settings.panelColor,
    "--ks-border":settings.borderColor,"--ks-section-space":`${settings.sectionSpacing}px`,
    "--ks-item-space":`${settings.itemSpacing}px`,"--ks-card-padding":`${settings.cardPadding}px`,
    "--ks-radius":`${settings.cardRadius}px`,"--ks-letter-spacing":`${settings.letterSpacing}em`,
    "--ks-line-height":String(settings.lineHeight),"--ks-glow":String(settings.glowStrength),"--ks-glow-size":`${Math.round(settings.glowStrength*58)}px`,
    "--ks-light-intensity":String(settings.lightingIntensity),"--ks-light-opacity":String(settings.lightingIntensity*.9),"--ks-light-speed":`${settings.lightingSpeed}s`,
    "--ks-title-transform":settings.titleTransform
  } as CSSProperties;

  function saveLocal(next:StoreConfig){setConfig(next);localStorage.setItem("ks_store_config_v2",JSON.stringify(next))}
  function navigate(next:AppView){
    if(next==="admin"&&!adminUnlocked){setAdminGateOpen(true);setMenuOpen(false);return}
    setAppView(next);setMenuOpen(false);window.scrollTo({top:0,behavior:"smooth"});
  }
  function selectCategory(next:StoreCategory){setCategory(next);setSocialPlatform(null);setInstagramType(null);navigate("category")}
  function toggleSound(){const a=audioRef.current;if(!a)return;if(soundOn){a.pause();setSoundOn(false)}else{a.volume=.28;a.play().catch(()=>{});setSoundOn(true)}}
  function changeQuantity(p:Product,d:number){
    setCart(current=>{
      const found=current.find(x=>x.id===p.id);
      if(!found&&d>0)return [...current,{...p,quantity:d}];
      if(!found)return current;
      return current.map(x=>x.id===p.id?{...x,quantity:x.quantity+d}:x).filter(x=>x.quantity>0);
    });
  }
  function qty(id:string,d:number){setCart(c=>c.map(x=>x.id===id?{...x,quantity:x.quantity+d}:x).filter(x=>x.quantity>0))}
  function saveProfile(){localStorage.setItem("ks_name",customerName);localStorage.setItem("ks_email",customerEmail);setAuthMessage(isEs?"Perfil guardado.":"Profile saved.")}
  function updateSettings<K extends keyof SiteSettings>(key:K,value:SiteSettings[K]){saveLocal({...config,settings:{...settings,[key]:value}})}
  function updateContent<K extends keyof SiteContent>(key:K,value:SiteContent[K]){saveLocal({...config,content:{...content,[key]:value}})}
  function updateCategoryCopy(categoryKey:StoreCategory,patch:Partial<CategoryCopy>){saveLocal({...config,content:{...content,categories:{...content.categories,[categoryKey]:{...content.categories[categoryKey],...patch}}}})}
  function updateProduct(id:string,patch:Partial<Product>){saveLocal({...config,products:products.map(p=>p.id===id?{...p,...patch}:p)})}
  function addProduct(){
    const next:Product={id:`custom-${Date.now()}`,name:"Nuevo producto",description:"",category:"Graphic Design",group:"Nueva sección",priceMXN:0,priceUSD:0,delivery:"Entrega digital"};
    saveLocal({...config,products:[next,...products]});setAdminSearch("");
  }
  function duplicateProduct(id:string){const source=products.find(p=>p.id===id);if(!source)return;const copy={...source,id:`${source.id}-copy-${Date.now()}`,name:`${source.name} Copy`};saveLocal({...config,products:[...products,copy]})}
  function deleteProduct(id:string){saveLocal({...config,products:products.filter(p=>p.id!==id)});setCart(c=>c.filter(p=>p.id!==id))}
  function moveProduct(id:string,direction:-1|1){const index=products.findIndex(p=>p.id===id);const target=index+direction;if(index<0||target<0||target>=products.length)return;const next=[...products];[next[index],next[target]]=[next[target],next[index]];saveLocal({...config,products:next})}
  async function publishConfig(){
    setPublishStatus(isEs?"Guardando...":"Saving...");
    try{
      const response=await fetch("/api/store-config",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(config)});
      if(response.status===401){setAdminUnlocked(false);setAdminGateOpen(true);setPublishStatus(isEs?"La sesión del panel expiró.":"Panel session expired.");return}
      const result=await response.json();
      if(result.config)saveLocal(normalizeStoreConfig(result.config));
      setPublishStatus(result.saved?(isEs?"Cambios publicados para todos.":"Changes published for everyone."):(isEs?"Guardado en este dispositivo. Conecta Redis/KV para publicar globalmente.":"Saved on this device. Connect Redis/KV to publish globally."));
    }catch{setPublishStatus(isEs?"Guardado localmente; no se pudo publicar.":"Saved locally; publishing failed.")}
  }
  function resetConfig(){const next=cloneDefault();saveLocal(next);setPublishStatus(isEs?"Configuración restablecida. Presiona Publicar para aplicarla globalmente.":"Configuration reset. Press Publish to apply it globally.")}
  function exportConfig(){const blob=new Blob([JSON.stringify(config,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="king-store-config.json";a.click();URL.revokeObjectURL(url)}
  async function importConfig(text:string){try{const next=normalizeStoreConfig(JSON.parse(text));saveLocal(next);setPublishStatus(isEs?"Respaldo importado. Revisa y publica.":"Backup imported. Review and publish.")}catch{setPublishStatus(isEs?"Ese archivo no es válido.":"That file is invalid.")}}
  async function unlockAdmin(){
    setAdminError("");
    try{
      const response=await fetch("/api/admin-login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pin:adminPin})});
      if(!response.ok){const result=await response.json().catch(()=>({}));setAdminError(response.status===503?(isEs?"Configura KING_PANEL_PIN y KING_PANEL_SECRET en Vercel.":"Configure KING_PANEL_PIN and KING_PANEL_SECRET in Vercel."):(result.error||(isEs?"PIN incorrecto.":"Incorrect PIN.")));return}
      setAdminUnlocked(true);setAdminGateOpen(false);setAdminPin("");setAppView("admin");window.history.replaceState({},"",window.location.pathname);
    }catch{setAdminError(isEs?"No se pudo validar el acceso.":"Access could not be validated.")}
  }
  async function logoutAdmin(){await fetch("/api/admin-logout",{method:"POST"}).catch(()=>{});setAdminUnlocked(false);setAppView("home")}
  async function handleMagicLink(){
    if(!customerEmail.trim()){setAuthMessage(isEs?"Escribe tu correo primero.":"Enter your email first.");return}
    setAuthBusy(true);setAuthMessage("");
    try{await sendMagicLink(customerEmail.trim());setAuthMessage(isEs?"Te enviamos un enlace seguro. Revisa tu correo.":"A secure login link was sent. Check your email.")}catch(error){setAuthMessage(error instanceof Error?error.message:(isEs?"No se pudo enviar el enlace.":"Could not send the link."))}finally{setAuthBusy(false)}
  }
  function handleOAuth(provider:AuthProvider){if(!startOAuth(provider))setAuthMessage(isEs?"Configura Supabase Auth para activar este acceso.":"Configure Supabase Auth to enable this login.")}
  async function handleClientLogout(){setAuthBusy(true);await signOutClient();setClientAccount(null);setAuthMessage(isEs?"Sesión cerrada.":"Signed out.");setAuthBusy(false)}

  const orderNumber=`KS-${new Date().toISOString().slice(2,10).replaceAll("-","")}-${customerId.slice(-4)||"0000"}`;
  const orderText=["👑 NUEVO PEDIDO — KING STORE","",`Pedido: ${orderNumber}`,`Cliente: ${customerName||"Sin especificar"}`,`Email: ${customerEmail||"No especificado"}`,`ID KING STORE: ${customerId}`,`ID / usuario / enlace: ${serviceId||"No especificado"}`,`Método de pago: ${paymentMethod}`,"","PRODUCTOS:",...cart.map(x=>`• ${x.group} — ${x.name}${x.duration?` (${x.duration})`:""} x${x.quantity} — $${x.priceMXN*x.quantity} 🇲🇽 / $${money(x.priceUSD*x.quantity)} 🇺🇸`),"",`TOTAL: $${totalMXN} 🇲🇽 / $${money(totalUSD)} 🇺🇸`,`Comprobante: ${receiptName||"Pendiente"}`].join("\n");
  async function continueToTelegram(){
    if(!customerName.trim()||!serviceId.trim()||!receiptName){setFormError(isEs?"Completa tu nombre, el ID/enlace y selecciona el comprobante.":"Complete your name, service ID/link, and select the receipt.");return}
    saveProfile();
    const localOrder:LocalOrder={id:orderNumber,createdAt:new Date().toISOString(),totalMXN,totalUSD,status:"Waiting",items:count};
    const next=[localOrder,...orders];setOrders(next);localStorage.setItem("ks_orders",JSON.stringify(next));setFormError("");
    const telegramWindow=window.open("about:blank","_blank");
    try{await navigator.clipboard.writeText(orderText);setOrderCopied(true)}catch{}
    const destination=telegramLink(orderText,content.telegramUsername);
    if(telegramWindow){telegramWindow.opener=null;telegramWindow.location.href=destination}else{window.location.href=destination}
  }

  return <main className="store-shell" style={shellStyle} data-lighting={settings.lightingEnabled} data-animations={settings.animationsEnabled} data-flags={settings.flagsDesktop}>
    <audio ref={audioRef} src="/thunder-ambience.wav" loop/>
    <div className="ambient-lighting" aria-hidden="true"><i/><i/><i/></div>

    {!entered&&<section className="intro"><div className="intro-atmosphere"/><img src="/ks-logo.png" alt="King Store"/><button type="button" className="royal-button intro-enter" onClick={()=>{setEntered(true);setAppView("categories");window.scrollTo({top:0,behavior:"auto"})}}>{titleCase(isEs?content.introButtonEs:content.introButtonEn)}<ChevronRight/></button></section>}

    <header className="topbar">
      <div className="top-left">
        <button className="nav-pill categories-pill" onClick={()=>setMenuOpen(true)}><LayoutGrid/><span>{isEs?"Categorías":"Categories"}</span></button>
        <nav className="desktop-nav">
          <button className={appView==="home"?"active":""} onClick={()=>navigate("home")}><Home/>{isEs?"Inicio":"Home"}</button>
          <button className={appView==="financial"?"active":""} onClick={()=>navigate("financial")}><WalletCards/>{isEs?"Finanzas":"Financial"}</button>
          <button className={appView==="account"?"active":""} onClick={()=>navigate("account")}><User/>{isEs?"Mi cuenta":"My Account"}</button>
          <button className={appView==="admin"?"active":""} onClick={()=>navigate("admin")}><LockKeyhole/>{adminUnlocked?"King Panel":"Panel"}</button>
        </nav>
      </div>
      <button className="brand" onClick={()=>navigate("home")}><img src="/ks-logo.png" alt="King Store"/></button>
      <div className="top-actions"><button className="icon-button panel-top-button" onClick={()=>navigate("admin")} aria-label="King Panel"><LockKeyhole/></button><button className="icon-button sound-button" onClick={toggleSound} aria-label={isEs?"Sonido":"Sound"}>{soundOn?<Volume2/>:<VolumeX/>}</button><button className="language-button" onClick={()=>setLang(isEs?"en":"es")}><Globe2 size={17}/><span>{lang.toUpperCase()}</span></button><button className="icon-button cart-top" onClick={()=>setCartOpen(true)} aria-label={isEs?"Carrito":"Cart"}><ShoppingBag/><b>{count}</b></button></div>
    </header>

    {menuOpen&&<button className="overlay" onClick={()=>setMenuOpen(false)} aria-label="Close menu"/>}
    <aside className={`side-menu ${menuOpen?"open":""}`}><div className="menu-head"><img src="/ks-logo.png" alt="King Store"/><button className="icon-button" onClick={()=>setMenuOpen(false)}><X/></button></div><button className="menu-home" onClick={()=>navigate("home")}><Home/>{isEs?"Inicio":"Home"}</button><nav>{categories.map(c=><button key={c} className={category===c&&appView==="category"?"active":""} onClick={()=>selectCategory(c)}><span className="menu-category"><CategoryEmblem category={c}/>{titleCase(content.categories[c][lang])}</span><ChevronRight size={17}/></button>)}</nav><div className="menu-links"><button onClick={()=>navigate("financial")}><WalletCards/>{isEs?"Finanzas":"Financial"}</button><button onClick={()=>navigate("account")}><User/>{isEs?"Mi cuenta":"My Account"}</button><button onClick={()=>navigate("admin")}><LockKeyhole/>{adminUnlocked?"King Panel":(isEs?"Panel privado":"Private panel")}</button></div></aside>

    {appView==="home"&&<HomePage isEs={isEs} content={content} onCategories={()=>navigate("categories")} onSelect={selectCategory}/>} 
    {appView==="categories"&&<CategoriesPage onSelect={selectCategory} lang={lang} content={content}/>} 
    {appView==="category"&&<CategoryPage category={category} lang={lang} content={content} products={categoryProducts} quantities={quantities} onQuantity={changeQuantity} socialPlatform={socialPlatform} setSocialPlatform={setSocialPlatform} instagramType={instagramType} setInstagramType={setInstagramType} onBack={()=>navigate("categories")}/>} 
    {appView==="financial"&&<FinancialPage orders={orders} isEs={isEs}/>} 
    {appView==="account"&&<AccountPage isEs={isEs} name={customerName} setName={setCustomerName} email={customerEmail} setEmail={setCustomerEmail} customerId={customerId} orders={orders} onSave={saveProfile} account={clientAccount} authEnabled={authConfigured()} authBusy={authBusy} authMessage={authMessage} onOAuth={handleOAuth} onMagicLink={handleMagicLink} onLogout={handleClientLogout}/>} 
    {appView==="admin"&&adminUnlocked&&<AdminPage isEs={isEs} config={config} products={filteredAdmin} search={adminSearch} setSearch={setAdminSearch} orders={orders} publishStatus={publishStatus} updateSettings={updateSettings} updateContent={updateContent} updateCategoryCopy={updateCategoryCopy} updateProduct={updateProduct} addProduct={addProduct} duplicateProduct={duplicateProduct} deleteProduct={deleteProduct} moveProduct={moveProduct} onPublish={publishConfig} onExport={exportConfig} onImport={importConfig} onReset={resetConfig} onLogout={logoutAdmin}/>} 

    <footer className="site-footer"><div className="social-dock"><a href={telegramLink("",content.telegramUsername)} target="_blank" rel="noreferrer" aria-label="Telegram"><Send/></a><a href={discordLink(content.discordInvite)} target="_blank" rel="noreferrer" aria-label="Discord"><MessagesSquare/></a></div><p>{titleCase(content.footerText)}</p></footer>
    <button className="floating-cart" onClick={()=>setCartOpen(true)}><ShoppingBag/><b>{count}</b></button>

    {cartOpen&&<button className="overlay" onClick={()=>setCartOpen(false)} aria-label="Close cart"/>}
    <aside className={`cart ${cartOpen?"open":""}`}><div className="cart-head"><h2>{isEs?"Tu carrito":"Your cart"}</h2><button className="icon-button" onClick={()=>setCartOpen(false)}><X/></button></div><div className="cart-list">{cart.length===0&&<p className="empty-cart">{isEs?"Tu carrito está vacío.":"Your cart is empty."}</p>}{cart.map(x=><div className="cart-item" key={x.id}><div><strong>{titleCase(x.name)}</strong><small>{titleCase(x.group)}<br/><PriceText amount={x.priceMXN} flag="mx"/> / <PriceText amount={x.priceUSD} flag="us"/></small></div><div className="qty"><button onClick={()=>qty(x.id,-1)}><Minus/></button><b>{x.quantity}</b><button onClick={()=>qty(x.id,1)}><Plus/></button><button onClick={()=>setCart(c=>c.filter(i=>i.id!==x.id))}><Trash2/></button></div></div>)}</div><div className="cart-foot"><strong><PriceText amount={totalMXN} flag="mx"/> / <PriceText amount={totalUSD} flag="us"/></strong><button className="checkout-button" disabled={!cart.length} onClick={()=>{setCartOpen(false);setCheckoutOpen(true)}}><Send/>{isEs?"Continuar Pedido":"Continue Order"}</button></div></aside>

    {checkoutOpen&&<div className="checkout-wrap" role="dialog" aria-modal="true"><button className="overlay" onClick={()=>setCheckoutOpen(false)}/><section className="checkout-modal"><header><div><small>King Store</small><h2>{isEs?"Confirmar Pedido":"Confirm Order"}</h2></div><button className="icon-button" onClick={()=>setCheckoutOpen(false)}><X/></button></header><div className="checkout-grid"><label><span>{isEs?"Nombre completo":"Full name"}</span><input value={customerName} onChange={e=>setCustomerName(e.target.value)} placeholder={isEs?"Nombre":"Name"}/></label><label><span>Email</span><input value={customerEmail} onChange={e=>setCustomerEmail(e.target.value)} placeholder="correo@ejemplo.com"/></label><label><span>ID KING STORE</span><input value={customerId} readOnly/></label><label><span>{isEs?"ID / usuario / enlace":"ID / username / link"}</span><input value={serviceId} onChange={e=>setServiceId(e.target.value)}/></label><label><span>{isEs?"Método de pago":"Payment method"}</span><select value={paymentMethod} onChange={e=>setPaymentMethod(e.target.value)}><option>Transferencia</option><option>Banco Azteca</option><option>OXXO</option><option>Otro</option></select></label><label className="receipt-field"><span>{isEs?"Comprobante":"Receipt"}</span><input type="file" accept="image/*" onChange={e=>setReceiptName(e.target.files?.[0]?.name||"")}/><span className="upload-button"><Upload/>{receiptName||(isEs?"Seleccionar captura":"Select screenshot")}</span></label></div><div className="order-summary"><span>{count} {isEs?"productos":"products"}</span><strong><PriceText amount={totalMXN} flag="mx"/> / <PriceText amount={totalUSD} flag="us"/></strong></div><p className="telegram-note">{isEs?"El resumen se copiará automáticamente. Adjunta tu comprobante cuando se abra Telegram.":"The order summary will be copied automatically. Attach your receipt when Telegram opens."}</p>{orderCopied&&<p className="copy-success">{isEs?"Resumen copiado.":"Order summary copied."}</p>}{formError&&<p className="form-error">{formError}</p>}<button className="send-order" onClick={continueToTelegram}><Send/>{isEs?"Enviar Pedido Por Telegram":"Send Order On Telegram"}</button></section></div>}

    {adminGateOpen&&<div className="admin-gate" role="dialog" aria-modal="true"><button className="overlay" onClick={()=>setAdminGateOpen(false)}/><section className="admin-gate-card"><LockKeyhole/><small>King Store</small><h2>King Panel</h2><p>{isEs?"Acceso privado del administrador. Solo entra quien conozca tu PIN.":"Private administrator access. Only someone with your PIN can enter."}</p><input type="password" inputMode="numeric" value={adminPin} onChange={e=>setAdminPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&unlockAdmin()} placeholder="PIN" autoFocus/>{adminError&&<p className="form-error">{adminError}</p>}<button className="save-button" onClick={unlockAdmin}><ShieldCheck/>{isEs?"Desbloquear":"Unlock"}</button></section></div>}
  </main>
}

function PriceText({amount,flag}:{amount:number;flag:"mx"|"us"}){return <span className="price-text"><b>${money(amount)}</b><span className="country-flag" aria-label={flag==="mx"?"Mexico":"United States"}>{flag==="mx"?"🇲🇽":"🇺🇸"}</span></span>}
function QuantityControl({product,quantity,onChange,label}:{product:Product;quantity:number;onChange:(p:Product,d:number)=>void;label:string}){return <div className="product-qty" aria-label={label}><button onClick={()=>onChange(product,-1)} disabled={quantity===0} aria-label="Decrease"><Minus/></button><b>{quantity}</b><button onClick={()=>onChange(product,1)} aria-label="Increase"><Plus/></button></div>}

function HomePage({isEs,content,onCategories,onSelect}:{isEs:boolean;content:SiteContent;onCategories:()=>void;onSelect:(c:StoreCategory)=>void}){
  return <><section className="hero upgraded-hero"><div className="hero-atmosphere"/><div className="hero-logo"><img src="/ks-logo.png" alt="King Store"/><p>{isEs?content.heroTaglineEs:content.heroTaglineEn}</p><small className="hero-announcement">{isEs?content.announcementEs:content.announcementEn}</small></div><div className="hero-bottom"><button className="royal-button" onClick={onCategories}><LayoutGrid/>{isEs?"Ver Categorías":"View Categories"}</button><a className="royal-button secondary" href={telegramLink("",content.telegramUsername)} target="_blank" rel="noreferrer"><Send/>Telegram</a></div></section><section className="home-strip"><article><ShieldCheck/><strong>{isEs?"Compra Segura":"Secure Purchase"}</strong><span>{isEs?"Atención directa":"Direct support"}</span></article><article><Bell/><strong>{isEs?"Seguimiento":"Tracking"}</strong><span>{isEs?"Estado de tu pedido":"Your order status"}</span></article><article><CreditCard/><strong>{isEs?"Dos Monedas":"Two Currencies"}</strong><span>MXN 🇲🇽 · USD 🇺🇸</span></article></section><section className="featured"><div className="section-title"><span>{titleCase(content.storeName)}</span><h2>{titleCase(isEs?content.featuredTitleEs:content.featuredTitleEn)}</h2></div><div className="category-grid featured-grid">{(["Free Fire","Superpowers","Social Media","Graphic Design"] as StoreCategory[]).map(c=><CategoryCard key={c} c={c} lang={isEs?"es":"en"} content={content} onSelect={onSelect}/>)}</div></section></>
}

function CategoriesPage({onSelect,lang,content}:{onSelect:(c:StoreCategory)=>void;lang:Lang;content:SiteContent}){return <section className="page-section"><div className="section-title"><span>{titleCase(content.storeName)}</span><h2>{lang==="es"?"Categorías":"Categories"}</h2></div><div className="category-grid">{categories.map(c=><CategoryCard key={c} c={c} lang={lang} content={content} onSelect={onSelect}/>)}</div></section>}
function CategoryCard({c,lang,content,onSelect}:{c:StoreCategory;lang:Lang;content:SiteContent;onSelect:(c:StoreCategory)=>void}){const copy=content.categories[c];return <button className={`category-card ${c==="Streaming"?"disabled":""}`} onClick={()=>c!=="Streaming"&&onSelect(c)}><span className="category-art"><CategoryEmblem category={c}/></span><div><small>{titleCase(content.storeName)}</small><strong>{titleCase(copy[lang])}</strong><p>{lang==="es"?copy.descEs:copy.descEn}</p></div><ChevronRight/></button>}

function CategoryPage({category,lang,content,products,quantities,onQuantity,socialPlatform,setSocialPlatform,instagramType,setInstagramType,onBack}:{category:StoreCategory;lang:Lang;content:SiteContent;products:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;socialPlatform:SocialPlatform|null;setSocialPlatform:(v:SocialPlatform|null)=>void;instagramType:InstagramType|null;setInstagramType:(v:InstagramType|null)=>void;onBack:()=>void}){
  const isEs=lang==="es";
  return <section className="page-section catalog"><button className="back-button" onClick={onBack}><ArrowLeft/>{isEs?"Volver A Categorías":"Back To Categories"}</button><div className="section-title"><span>{titleCase(content.storeName)}</span><h2>{titleCase(content.categories[category][lang])}</h2></div>{category==="Free Fire"&&<ExpandableDiamondCards items={products} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>} {category==="Superpowers"&&<SuperpowerTables items={products} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>} {category==="Social Media"&&<SocialTree items={products} platform={socialPlatform} setPlatform={setSocialPlatform} instagramType={instagramType} setInstagramType={setInstagramType} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>} {category==="Streaming"&&<div className="coming">{isEs?"Próximamente":"Coming Soon"}</div>}{(category==="Graphic Design"||category==="Métodos")&&<GenericTables items={products} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>}<a className="work-button" href={telegramLink("",content.telegramUsername)} target="_blank" rel="noreferrer"><Send/>{titleCase(isEs?content.workButtonEs:content.workButtonEn)}</a><button className="back-button bottom-back" onClick={onBack}><ArrowLeft/>{isEs?"Volver A Categorías":"Back To Categories"}</button></section>
}

function ExpandableDiamondCards({items,quantities,onQuantity,isEs}:{items:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){const groups=["Promo Diamonds","Unlimited Diamonds"];return <div className="diamond-card-grid">{groups.map((g,i)=><details className="expand-card" key={g}><summary><div className="diamond-visual">{i===0?<Crown/>:<Gem/>}</div><div><small>King Store</small><h3>{titleCase(g)}</h3><p>{i===0?(isEs?"Bonos incluidos · cantidades totales":"Bonuses included · total amounts"):(isEs?"Más opciones para cada compra":"More options for every purchase")}</p></div><span className="select-label">{isEs?"Selecciona Tu Paquete":"Select Your Package"} <ChevronDown/></span></summary><div className="expand-options">{items.filter(p=>p.group===g).map(p=><div className="option-row product-sale-item" key={p.id}><strong>{p.icon&&<span>{p.icon}</span>}{titleCase(p.name.replace(" Diamantes",""))} <Gem className="inline-gem"/></strong><PriceText amount={p.priceMXN} flag="mx"/><PriceText amount={p.priceUSD} flag="us"/><QuantityControl product={p} quantity={quantities[p.id]||0} onChange={onQuantity} label={isEs?"Cantidad":"Quantity"}/></div>)}</div></details>)}</div>}

function FinancialPage({orders,isEs}:{orders:LocalOrder[];isEs:boolean}){const spent=orders.reduce((s,o)=>s+o.totalMXN,0);return <section className="page-section"><div className="section-title"><span>KING STORE</span><h2>{isEs?"Finanzas":"Financial"}</h2></div><div className="dashboard-cards"><Stat icon={<WalletCards/>} title={isEs?"Cartera":"Wallet"} value="$0 MXN"/><Stat icon={<ReceiptText/>} title={isEs?"Historial":"History"} value={`${orders.length} ${isEs?"pedidos":"orders"}`}/><Stat icon={<CircleDollarSign/>} title={isEs?"Compras registradas":"Recorded purchases"} value={`$${spent} MXN`}/></div><OrderList orders={orders} isEs={isEs}/></section>}

function ProviderBadge({provider}:{provider:string}){if(provider==="google")return <Chrome/>;if(provider==="apple")return <Apple/>;return <Globe2/>}
function AccountPage({isEs,name,setName,email,setEmail,customerId,orders,onSave,account,authEnabled,authBusy,authMessage,onOAuth,onMagicLink,onLogout}:{isEs:boolean;name:string;setName:(v:string)=>void;email:string;setEmail:(v:string)=>void;customerId:string;orders:LocalOrder[];onSave:()=>void;account:ClientAccount|null;authEnabled:boolean;authBusy:boolean;authMessage:string;onOAuth:(provider:AuthProvider)=>void;onMagicLink:()=>void;onLogout:()=>void}){
  return <section className="page-section"><div className="section-title"><span>KING STORE</span><h2>{isEs?"Mi cuenta":"My Account"}</h2></div><div className="account-layout"><article className="panel-card account-card"><header><User/><div><small>ID PERSONAL</small><strong>{customerId}</strong></div></header>{account&&<div className="linked-account">{account.avatarUrl?<img src={account.avatarUrl} alt=""/>:<ProviderBadge provider={account.provider}/>}<div><small>{isEs?"CUENTA CONECTADA":"CONNECTED ACCOUNT"}</small><strong>{account.name}</strong><span>{account.email}</span></div><button onClick={onLogout} disabled={authBusy}><LogOut/></button></div>}<label>{isEs?"Nombre":"Name"}<input value={name} onChange={e=>setName(e.target.value)}/></label><label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label><button className="save-button" onClick={onSave}><ShieldCheck/>{isEs?"GUARDAR PERFIL":"SAVE PROFILE"}</button>{!account&&<><div className="auth-divider"><span>{isEs?"CONECTA TU CUENTA PREFERIDA":"CONNECT YOUR PREFERRED ACCOUNT"}</span></div><div className="auth-provider-grid"><button onClick={()=>onOAuth("google")} disabled={!authEnabled||authBusy}><Chrome/>Google</button><button onClick={()=>onOAuth("apple")} disabled={!authEnabled||authBusy}><Apple/>Apple</button><button onClick={()=>onOAuth("azure")} disabled={!authEnabled||authBusy}><span className="microsoft-mark"><i/><i/><i/><i/></span>Microsoft</button><button onClick={onMagicLink} disabled={!authEnabled||authBusy}><Send/>{isEs?"Enlace por email":"Email link"}</button></div></>}{authMessage&&<p className="auth-message">{authMessage}</p>}<p className="security-note"><LogIn/>{authEnabled?(isEs?"Acceso seguro por correo, Google, Apple o Microsoft.":"Secure access with email, Google, Apple, or Microsoft."):(isEs?"Agrega las variables de Supabase incluidas en el README para activar los accesos reales.":"Add the Supabase variables listed in the README to activate real logins.")}</p></article><OrderList orders={orders} isEs={isEs}/></div></section>
}

function AdminPage({isEs,config,products,search,setSearch,orders,publishStatus,updateSettings,updateContent,updateCategoryCopy,updateProduct,addProduct,duplicateProduct,deleteProduct,moveProduct,onPublish,onExport,onImport,onReset,onLogout}:{isEs:boolean;config:StoreConfig;products:Product[];search:string;setSearch:(v:string)=>void;orders:LocalOrder[];publishStatus:string;updateSettings:<K extends keyof SiteSettings>(key:K,value:SiteSettings[K])=>void;updateContent:<K extends keyof SiteContent>(key:K,value:SiteContent[K])=>void;updateCategoryCopy:(key:StoreCategory,patch:Partial<CategoryCopy>)=>void;updateProduct:(id:string,patch:Partial<Product>)=>void;addProduct:()=>void;duplicateProduct:(id:string)=>void;deleteProduct:(id:string)=>void;moveProduct:(id:string,direction:-1|1)=>void;onPublish:()=>void;onExport:()=>void;onImport:(text:string)=>void;onReset:()=>void;onLogout:()=>void}){
  const [tab,setTab]=useState<AdminTab>("design");
  const {settings,content}=config;
  return <section className="page-section admin-page"><div className="section-title"><span>ADMIN ONLY</span><h2>King Panel</h2></div><div className="admin-warning"><ShieldCheck/><div><strong>{isEs?"Panel privado desbloqueado":"Private panel unlocked"}</strong><p>{isEs?"Aquí puedes controlar diseño, texto, productos, precios, visibilidad, orden y respaldos.":"Control design, copy, products, prices, visibility, order, and backups here."}</p></div></div><div className="admin-command-bar"><button className="primary-admin" onClick={onPublish}><ShieldCheck/>{isEs?"PUBLICAR CAMBIOS":"PUBLISH CHANGES"}</button><button onClick={onExport}><Upload/>{isEs?"Exportar":"Export"}</button><label className="admin-file-button"><Upload/>{isEs?"Importar":"Import"}<input type="file" accept="application/json" onChange={async e=>{const file=e.target.files?.[0];if(file)onImport(await file.text());e.currentTarget.value=""}}/></label><button onClick={onReset}>{isEs?"Restablecer":"Reset"}</button><button onClick={onLogout}><LogOut/>{isEs?"Cerrar panel":"Lock panel"}</button></div>{publishStatus&&<p className="publish-status">{publishStatus}</p>}<div className="dashboard-cards"><Stat icon={<Package/>} title={isEs?"Productos":"Products"} value={String(config.products.length)}/><Stat icon={<Bell/>} title={isEs?"En espera":"Waiting"} value={String(orders.filter(o=>o.status==="Waiting").length)}/><Stat icon={<Users/>} title={isEs?"Ocultos":"Hidden"} value={String(config.products.filter(p=>p.hidden).length)}/></div><nav className="admin-tabs"><button className={tab==="design"?"active":""} onClick={()=>setTab("design")}>{isEs?"Diseño":"Design"}</button><button className={tab==="content"?"active":""} onClick={()=>setTab("content")}>{isEs?"Textos y enlaces":"Copy & links"}</button><button className={tab==="products"?"active":""} onClick={()=>setTab("products")}>{isEs?"Productos":"Products"}</button><button className={tab==="backup"?"active":""} onClick={()=>setTab("backup")}>{isEs?"Publicación":"Publishing"}</button></nav>

    {tab==="design"&&<div className="admin-editor-grid"><AdminSection title={isEs?"Tipografía":"Typography"}><Control label={isEs?"Fuente de títulos":"Title font"}><select value={settings.titleFont} onChange={e=>updateSettings("titleFont",e.target.value)}>{fontOptions.map(f=><option key={f.label} value={f.value}>{f.label}</option>)}</select></Control><Control label={isEs?"Fuente general":"Body font"}><select value={settings.bodyFont} onChange={e=>updateSettings("bodyFont",e.target.value)}>{fontOptions.map(f=><option key={f.label} value={f.value}>{f.label}</option>)}</select></Control><RangeControl label={isEs?"Tamaño general":"Body size"} value={settings.bodyFontSize} min={12} max={24} onChange={v=>updateSettings("bodyFontSize",v)}/><RangeControl label={isEs?"Título principal":"Main title"} value={settings.titleSize} min={30} max={110} onChange={v=>updateSettings("titleSize",v)}/><RangeControl label={isEs?"Título de tarjetas":"Card title"} value={settings.cardTitleSize} min={20} max={64} onChange={v=>updateSettings("cardTitleSize",v)}/><RangeControl label={isEs?"Precios":"Prices"} value={settings.priceSize} min={13} max={32} onChange={v=>updateSettings("priceSize",v)}/><Control label={isEs?"Formato de título":"Title formatting"}><select value={settings.titleTransform} onChange={e=>updateSettings("titleTransform",e.target.value as SiteSettings["titleTransform"])}><option value="none">Normal</option><option value="uppercase">UPPERCASE</option><option value="capitalize">Capitalize</option></select></Control></AdminSection><AdminSection title={isEs?"Colores":"Colors"}><ColorControl label={isEs?"Título":"Title"} value={settings.titleColor} onChange={v=>updateSettings("titleColor",v)}/><ColorControl label={isEs?"Acento principal":"Main accent"} value={settings.accentColor} onChange={v=>updateSettings("accentColor",v)}/><ColorControl label={isEs?"Acento secundario":"Second accent"} value={settings.accentColor2} onChange={v=>updateSettings("accentColor2",v)}/><ColorControl label={isEs?"Texto":"Text"} value={settings.textColor} onChange={v=>updateSettings("textColor",v)}/><ColorControl label={isEs?"Texto suave":"Muted text"} value={settings.mutedColor} onChange={v=>updateSettings("mutedColor",v)}/><ColorControl label={isEs?"Fondo de tarjetas":"Card background"} value={settings.panelColor} onChange={v=>updateSettings("panelColor",v)}/><ColorControl label={isEs?"Bordes":"Borders"} value={settings.borderColor} onChange={v=>updateSettings("borderColor",v)}/></AdminSection><AdminSection title={isEs?"Espaciado y formato":"Spacing & formatting"}><RangeControl label={isEs?"Espacio de secciones":"Section spacing"} value={settings.sectionSpacing} min={24} max={150} onChange={v=>updateSettings("sectionSpacing",v)}/><RangeControl label={isEs?"Espacio entre artículos":"Item spacing"} value={settings.itemSpacing} min={6} max={70} onChange={v=>updateSettings("itemSpacing",v)}/><RangeControl label={isEs?"Relleno de tarjetas":"Card padding"} value={settings.cardPadding} min={10} max={60} onChange={v=>updateSettings("cardPadding",v)}/><RangeControl label={isEs?"Esquinas":"Corner radius"} value={settings.cardRadius} min={0} max={48} onChange={v=>updateSettings("cardRadius",v)}/><RangeControl label={isEs?"Interlineado x10":"Line height x10"} value={Math.round(settings.lineHeight*10)} min={11} max={22} onChange={v=>updateSettings("lineHeight",v/10)}/><RangeControl label={isEs?"Separación de letras x100":"Letter spacing x100"} value={Math.round(settings.letterSpacing*100)} min={0} max={25} onChange={v=>updateSettings("letterSpacing",v/100)}/></AdminSection><AdminSection title={isEs?"Iluminación continua":"Continuous lighting"}><ToggleControl label={isEs?"Iluminación en toda la página":"Lighting across the entire page"} checked={settings.lightingEnabled} onChange={v=>updateSettings("lightingEnabled",v)}/><ToggleControl label={isEs?"Animaciones":"Animations"} checked={settings.animationsEnabled} onChange={v=>updateSettings("animationsEnabled",v)}/><ToggleControl label={isEs?"Banderas en escritorio":"Desktop flags"} checked={settings.flagsDesktop} onChange={v=>updateSettings("flagsDesktop",v)}/><RangeControl label={isEs?"Intensidad de luz x100":"Lighting intensity x100"} value={Math.round(settings.lightingIntensity*100)} min={0} max={100} onChange={v=>updateSettings("lightingIntensity",v/100)}/><RangeControl label={isEs?"Brillo de tarjetas x100":"Card glow x100"} value={Math.round(settings.glowStrength*100)} min={0} max={100} onChange={v=>updateSettings("glowStrength",v/100)}/><RangeControl label={isEs?"Velocidad de luz":"Lighting speed"} value={settings.lightingSpeed} min={4} max={30} onChange={v=>updateSettings("lightingSpeed",v)}/></AdminSection></div>}

    {tab==="content"&&<div className="admin-editor-grid"><AdminSection title={isEs?"Página principal":"Home page"}><TextControl label={isEs?"Nombre de tienda":"Store name"} value={content.storeName} onChange={v=>updateContent("storeName",v)}/><TextControl label="Hero ES" value={content.heroTaglineEs} onChange={v=>updateContent("heroTaglineEs",v)}/><TextControl label="Hero EN" value={content.heroTaglineEn} onChange={v=>updateContent("heroTaglineEn",v)}/><TextControl label={isEs?"Anuncio ES":"Announcement ES"} value={content.announcementEs} onChange={v=>updateContent("announcementEs",v)}/><TextControl label={isEs?"Anuncio EN":"Announcement EN"} value={content.announcementEn} onChange={v=>updateContent("announcementEn",v)}/><TextControl label={isEs?"Botón de entrada ES":"Entry button ES"} value={content.introButtonEs} onChange={v=>updateContent("introButtonEs",v)}/><TextControl label={isEs?"Botón de entrada EN":"Entry button EN"} value={content.introButtonEn} onChange={v=>updateContent("introButtonEn",v)}/><TextControl label={isEs?"Pie de página":"Footer"} value={content.footerText} onChange={v=>updateContent("footerText",v)}/></AdminSection><AdminSection title={isEs?"Contacto":"Contact"}><TextControl label="Telegram username" value={content.telegramUsername} onChange={v=>updateContent("telegramUsername",v.replace(/^@/,""))}/><TextControl label="Discord invite URL" value={content.discordInvite} onChange={v=>updateContent("discordInvite",v)}/><TextControl label={isEs?"Trabaja con nosotros ES":"Work button ES"} value={content.workButtonEs} onChange={v=>updateContent("workButtonEs",v)}/><TextControl label={isEs?"Trabaja con nosotros EN":"Work button EN"} value={content.workButtonEn} onChange={v=>updateContent("workButtonEn",v)}/></AdminSection>{categories.map(c=><AdminSection key={c} title={`${isEs?"Categoría":"Category"}: ${c}`}><TextControl label="Nombre ES" value={content.categories[c].es} onChange={v=>updateCategoryCopy(c,{es:v})}/><TextControl label="Name EN" value={content.categories[c].en} onChange={v=>updateCategoryCopy(c,{en:v})}/><TextControl label="Descripción ES" value={content.categories[c].descEs} onChange={v=>updateCategoryCopy(c,{descEs:v})}/><TextControl label="Description EN" value={content.categories[c].descEn} onChange={v=>updateCategoryCopy(c,{descEn:v})}/></AdminSection>)}</div>}

    {tab==="products"&&<article className="admin-products expanded-admin-products"><header><div><small>FULL CATALOG CONTROL</small><h3>{isEs?"Edita cualquier producto":"Edit any product"}</h3></div><button className="primary-admin" onClick={addProduct}><Plus/>{isEs?"NUEVO PRODUCTO":"NEW PRODUCT"}</button></header><div className="search-box"><Search/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={isEs?"Buscar producto, grupo o categoría...":"Search product, group, or category..."}/></div><div className="product-admin-list">{products.map((p,index)=><details className="product-admin-card" key={p.id}><summary><div className="product-admin-summary"><span className={`visibility-dot ${p.hidden?"hidden":""}`}/><div><strong>{p.name}</strong><small>{p.category} · {p.group}{p.duration?` · ${p.duration}`:""}</small></div><PriceText amount={p.priceMXN} flag="mx"/><PriceText amount={p.priceUSD} flag="us"/></div><ChevronDown/></summary><div className="product-admin-form"><TextControl label={isEs?"Nombre":"Name"} value={p.name} onChange={v=>updateProduct(p.id,{name:v})}/><Control label={isEs?"Categoría":"Category"}><select value={p.category} onChange={e=>updateProduct(p.id,{category:e.target.value as StoreCategory})}>{categories.map(c=><option key={c}>{c}</option>)}</select></Control><TextControl label={isEs?"Grupo / tabla":"Group / table"} value={p.group} onChange={v=>updateProduct(p.id,{group:v})}/><TextControl label={isEs?"Descripción":"Description"} value={p.description} onChange={v=>updateProduct(p.id,{description:v})}/><TextControl label={isEs?"Duración":"Duration"} value={p.duration||""} onChange={v=>updateProduct(p.id,{duration:v||undefined})}/><TextControl label={isEs?"Emblema corto":"Short emblem"} value={p.icon||""} onChange={v=>updateProduct(p.id,{icon:v.slice(0,4)})}/><NumberControl label="MXN 🇲🇽" value={p.priceMXN} step={0.5} onChange={v=>updateProduct(p.id,{priceMXN:v})}/><NumberControl label="USD 🇺🇸" value={p.priceUSD} step={0.25} onChange={v=>updateProduct(p.id,{priceUSD:v})}/><ToggleControl label={isEs?"Ocultar del sitio":"Hide from website"} checked={Boolean(p.hidden)} onChange={v=>updateProduct(p.id,{hidden:v})}/><ToggleControl label={isEs?"Destacado":"Featured"} checked={Boolean(p.featured)} onChange={v=>updateProduct(p.id,{featured:v})}/><div className="product-admin-actions"><button onClick={()=>moveProduct(p.id,-1)} disabled={index===0}><ChevronUp/></button><button onClick={()=>moveProduct(p.id,1)} disabled={index===products.length-1}><ChevronDown/></button><button onClick={()=>duplicateProduct(p.id)}><Plus/>{isEs?"Duplicar":"Duplicate"}</button><button className="danger" onClick={()=>deleteProduct(p.id)}><Trash2/>{isEs?"Eliminar":"Delete"}</button></div></div></details>)}</div></article>}

    {tab==="backup"&&<div className="admin-editor-grid"><AdminSection title={isEs?"Cómo publicar para todos":"How to publish for everyone"}><p className="admin-help">{isEs?"El botón Publicar guarda el diseño y catálogo en Redis/KV cuando las variables están configuradas. Sin Redis/KV, los cambios se guardan de forma segura en este navegador y puedes moverlos con Exportar/Importar.":"Publish saves the design and catalog to Redis/KV when the variables are configured. Without Redis/KV, changes stay safely in this browser and can be moved with Export/Import."}</p><button className="primary-admin large-admin-action" onClick={onPublish}><ShieldCheck/>{isEs?"PUBLICAR AHORA":"PUBLISH NOW"}</button></AdminSection><AdminSection title={isEs?"Respaldo completo":"Complete backup"}><p className="admin-help">{isEs?"Exporta todo: productos, textos, colores, fuentes, tamaños, formato, espaciado y luces.":"Export everything: products, copy, colors, fonts, sizes, formatting, spacing, and lighting."}</p><button className="large-admin-action" onClick={onExport}><Upload/>{isEs?"DESCARGAR RESPALDO":"DOWNLOAD BACKUP"}</button><label className="admin-file-button large-admin-action"><Upload/>{isEs?"CARGAR RESPALDO":"LOAD BACKUP"}<input type="file" accept="application/json" onChange={async e=>{const file=e.target.files?.[0];if(file)onImport(await file.text());e.currentTarget.value=""}}/></label></AdminSection><AdminSection title={isEs?"Seguridad":"Security"}><p className="admin-help">{isEs?"El panel se valida en el servidor con un PIN privado y una cookie HttpOnly. Nunca pongas el PIN en variables NEXT_PUBLIC.":"The panel is validated on the server with a private PIN and an HttpOnly cookie. Never place the PIN in a NEXT_PUBLIC variable."}</p><button className="danger large-admin-action" onClick={onLogout}><LockKeyhole/>{isEs?"BLOQUEAR PANEL":"LOCK PANEL"}</button></AdminSection></div>}
  </section>
}

function AdminSection({title,children}:{title:string;children:ReactNode}){return <article className="admin-section"><h3>{title}</h3><div className="admin-controls">{children}</div></article>}
function Control({label,children}:{label:string;children:ReactNode}){return <label className="admin-control"><span>{label}</span>{children}</label>}
function TextControl({label,value,onChange}:{label:string;value:string;onChange:(value:string)=>void}){return <Control label={label}><input value={value} onChange={e=>onChange(e.target.value)}/></Control>}
function NumberControl({label,value,step,onChange}:{label:string;value:number;step:number;onChange:(value:number)=>void}){return <Control label={label}><input type="number" step={step} value={value} onChange={e=>onChange(Math.max(0,Number(e.target.value)))}/></Control>}
function ColorControl({label,value,onChange}:{label:string;value:string;onChange:(value:string)=>void}){return <Control label={label}><div className="color-input"><input type="color" value={value} onChange={e=>onChange(e.target.value)}/><input value={value} onChange={e=>/^#[0-9a-fA-F]{0,6}$/.test(e.target.value)&&onChange(e.target.value)}/></div></Control>}
function RangeControl({label,value,min,max,onChange}:{label:string;value:number;min:number;max:number;onChange:(value:number)=>void}){return <Control label={`${label}: ${value}`}><input type="range" min={min} max={max} value={value} onChange={e=>onChange(Number(e.target.value))}/></Control>}
function ToggleControl({label,checked,onChange}:{label:string;checked:boolean;onChange:(value:boolean)=>void}){return <label className="toggle-control"><span>{label}</span><input type="checkbox" checked={checked} onChange={e=>onChange(e.target.checked)}/><i/></label>}
function Stat({icon,title,value}:{icon:ReactNode;title:string;value:string}){return <article className="stat-card">{icon}<small>{title}</small><strong>{value}</strong></article>}
function OrderList({orders,isEs}:{orders:LocalOrder[];isEs:boolean}){return <article className="panel-card order-panel"><header><ReceiptText/><div><small>{isEs?"ACTIVIDAD":"ACTIVITY"}</small><strong>{isEs?"Historial de pedidos":"Order history"}</strong></div></header>{orders.length===0?<p className="empty-state">{isEs?"Todavía no hay pedidos guardados en este dispositivo.":"No orders saved on this device yet."}</p>:orders.map(o=><div className="order-line" key={o.id}><div><strong>{o.id}</strong><small>{new Date(o.createdAt).toLocaleString()}</small></div><span>{o.status}</span><PriceText amount={o.totalMXN} flag="mx"/></div>)}</article>}

function SuperpowerTables({items,quantities,onQuantity,isEs}:{items:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){return <div className="two-column-tables superpower-split"><ServiceTable title="iOS" items={items.filter(p=>p.group==="iOS")} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/><ServiceTable title="Android" items={items.filter(p=>p.group==="Android")} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/></div>}
function SocialTree({items,platform,setPlatform,instagramType,setInstagramType,quantities,onQuantity,isEs}:{items:Product[];platform:SocialPlatform|null;setPlatform:(v:SocialPlatform|null)=>void;instagramType:InstagramType|null;setInstagramType:(v:InstagramType|null)=>void;quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){
  if(!platform)return <div className="platform-grid">{socialPlatforms.map(p=><button className="platform-card" key={p.name} onClick={()=>setPlatform(p.name)}><span className="platform-icon"><BrandEmblem brand={p.name}/></span><strong>{titleCase(p.name)}</strong><small>{titleCase(p.subtitle)}</small><ChevronRight/></button>)}</div>;
  const back=<button className="back-button" onClick={()=>{if(instagramType)setInstagramType(null);else setPlatform(null)}}><ArrowLeft/>{instagramType?"Instagram":(isEs?"Redes Sociales":"Social Media")}</button>;
  if(platform==="Instagram"&&!instagramType)return <div>{back}<div className="platform-grid compact">{(["Followers","Likes","Views"] as InstagramType[]).map(type=><button className="platform-card" key={type} onClick={()=>setInstagramType(type)}><span className="platform-icon"><BrandEmblem brand="Instagram"/></span><strong>{titleCase(`Instagram ${type}`)}</strong><small>{type==="Views"?(isEs?"Tabla De Precios":"Price Table"):"No Refill · Refill"}</small><ChevronRight/></button>)}</div></div>;
  let groups:string[]=[];if(platform==="Instagram"&&instagramType){groups=instagramType==="Views"?["Instagram Views"]:[`Instagram ${instagramType} · No Refill`,`Instagram ${instagramType} · Refill`]}else if(platform==="Facebook")groups=["Facebook Followers · No Refill","Facebook Followers · Refill"];else if(platform==="TikTok")groups=["TikTok Followers · No Refill","TikTok Followers · Refill"];else groups=["Telegram Members"];
  return <div>{back}<div className={groups.length===2?"two-column-tables":"single-table"}>{groups.map(g=><PriceTable key={g} title={g.replace(" · "," — ")} items={items.filter(p=>p.group===g)} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>)}</div></div>
}
function PriceTable({title,subtitle,items,quantities,onQuantity,isEs}:{title:string;subtitle?:string;items:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){return <details className="price-panel collapsible-price-panel"><summary className="price-panel-summary"><div><small>{titleCase(subtitle||"King Store")}</small><h3>{titleCase(title)}</h3></div><span>{isEs?"Ver Opciones":"View Options"}<ChevronDown/></span></summary><div className="price-panel-body"><div className="price-head"><span>{isEs?"Plan":"Plan"}</span><span>MXN 🇲🇽</span><span>USD 🇺🇸</span><span>{isEs?"Cant.":"Qty"}</span></div>{items.map((p,i)=><div className="price-row product-sale-item" key={p.id} data-alt={i%2===1}><strong>{p.icon&&<span className="product-icon-text">{p.icon}</span>}{titleCase(p.name)}</strong><PriceText amount={p.priceMXN} flag="mx"/><PriceText amount={p.priceUSD} flag="us"/><QuantityControl product={p} quantity={quantities[p.id]||0} onChange={onQuantity} label={isEs?"Cantidad":"Quantity"}/></div>)}</div></details>}
function ServiceTable({title,items,quantities,onQuantity,isEs}:{title:string;items:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){const names=[...new Set(items.map(p=>p.name))];return <details className="price-panel service-panel collapsible-price-panel"><summary className="price-panel-summary"><div><small>Superpowers</small><h3>{titleCase(title)}</h3></div><span>{isEs?"Ver Opciones":"View Options"}<ChevronDown/></span></summary><div className="price-panel-body"><div className="price-head service-head"><span>{isEs?"Plan":"Plan"}</span><span>MXN 🇲🇽</span><span>USD 🇺🇸</span><span>{isEs?"Cant.":"Qty"}</span></div>{names.map(name=><section className="service-block" key={name}><h4>{titleCase(name)}</h4>{items.filter(p=>p.name===name).map((p,i)=><div className="service-row product-sale-item" key={p.id} data-alt={i%2===1}><strong>{titleCase(p.duration||p.name)}</strong><PriceText amount={p.priceMXN} flag="mx"/><PriceText amount={p.priceUSD} flag="us"/><QuantityControl product={p} quantity={quantities[p.id]||0} onChange={onQuantity} label={isEs?"Cantidad":"Quantity"}/></div>)}</section>)}</div></details>}
function GenericTables({items,quantities,onQuantity,isEs}:{items:Product[];quantities:Record<string,number>;onQuantity:(p:Product,d:number)=>void;isEs:boolean}){const groups=[...new Set(items.map(p=>p.group))];return <div className="group-table-grid">{groups.map(g=><PriceTable key={g} title={g} items={items.filter(p=>p.group===g)} quantities={quantities} onQuantity={onQuantity} isEs={isEs}/>)}</div>}
