"use client";

import { Crown, Send } from "lucide-react";
import type { Product } from "@/data/products";
import type { Lang } from "@/lib/format";
import { telegramLink } from "@/lib/format";

type Props={product:Product;lang:Lang;onAdd:(product:Product)=>void};
export default function ProductCard({product,lang,onAdd}:Props){
  const isEs=lang==="es";
  const message=isEs?`Hola King Store, quiero comprar ${product.name}. Precio: $${product.priceMXN} 🇲🇽 / $${product.priceUSD} 🇺🇸.`:`Hi King Store, I want to buy ${product.name}. Price: $${product.priceMXN} 🇲🇽 / $${product.priceUSD} 🇺🇸.`;
  return <article className="product-card"><div className="card-light"/><div className="card-crown"><Crown/></div><span className="product-group">{product.group}</span><h3>{product.name}</h3><div className="dual-price"><span><small>MXN 🇲🇽</small>${product.priceMXN}</span><i/><span><small>USD 🇺🇸</small>${product.priceUSD}</span></div><div className="product-actions"><button onClick={()=>onAdd(product)}>{isEs?"Agregar":"Add"}</button><a href={telegramLink(message)} target="_blank" rel="noreferrer"><Send size={17}/></a></div></article>;
}
